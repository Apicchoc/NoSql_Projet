import json
import os

path = "./data_json/"
for file in os.listdir(path):
    with open(path + file, 'r') as f:
        data = json.load(f)

    for i in range(len(data)):
        data[i] = json.dumps(data[i])+"\n"
    
    with open(path+ file, 'w') as f:
        f.writelines(data)
