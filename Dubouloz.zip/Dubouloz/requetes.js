

db.plaintes.aggregate([
  { $group: { _id : "$BORO_NM", 
      total : {$sum:1}}}, { $sort: {total : 1}}])
      
      
db.airquality.aggregate([
{$match: { geo_type_name : "Borough"}},
  { $group: { _id : "$geo_entity_name", 
      total : {$sum:"$data_valuemessage"}}},
      { $sort: {total : 1}}])
      
db.tennis.aggregate([{
    $match:{Prop_ID:/R/}},
    {$lookup:
        {
            from: "basket",
            localField:"Name",
            foreignField:"Name",
            as:"tennis_et_basket"
        }
    }
])
    
db.tennis.find({Name: "Walker Park"})
      

    

    

    

    
